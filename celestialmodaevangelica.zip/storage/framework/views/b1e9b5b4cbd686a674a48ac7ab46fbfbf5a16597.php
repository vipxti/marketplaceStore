<!DOCTYPE html>

<html lang="pt-br">

  <head>

    <?php echo $__env->make('partials.admin._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
  </head>

  <body class="hold-transition skin-blue sidebar-mini">

    <div class="wrapper">

      <?php echo $__env->make('partials.admin._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->make('partials.admin._aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      <?php echo $__env->yieldContent('content'); ?>

      <?php echo $__env->make('partials.admin._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
    <!-- ./wrapper -->

  </body>

</html>
