<!DOCTYPE html>

<html lang="pt-br">

    <head>

        <?php echo $__env->make('partials.admin._headpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body class="hold-transition login-page">

        <div class="top_logo" align="center">

            <a href="#"><img src="<?php echo e(asset('img/app/core-img/logo.png')); ?>" alt=""></a>

        </div>

        <?php echo $__env->yieldContent('content'); ?>

        <!-- jQuery 3 -->


    </body>

</html>
