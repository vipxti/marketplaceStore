<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
              <div class="content-wrapper">
    <!-- Content Header (Page header) -->

                    <section class="content-header">
                       <h1>Aparência</h1>
                         <ol class="breadcrumb">
                              <li>,.<a href="<?php echo e(route('admin.dashboard')); ?>"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                              <li><a href="<?php echo e(route('admin.dashboard')); ?>">Configurações</a></li>
                              <li><a class="active">Personalização</a></li>
                        </ol>
                    </section>

                    <section id="content" class="content">



                        <!--ALTERAÇÕES DA INDEX (HEADER)-->
                        <div class="col-md-12">
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <div class="box-tools pull-right">
                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    </div>
                                </div>

                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label>Menu</label>
                                        <div class="input-group">
                                            <span class="input-group-addon"><i class="fa fa-barcode"></i></span>
                                            <input type="text" class="form-control" name="cd_ean">
                                        </div>
                                    </div>
                                </div>


                                <div class="box-body">
                                    <div class="row">

                                        <div class="col-md-12">
                                            <form id="fCat" class="form-horizontal" action="#" method="post">
                                                <button type="submit" class="btn btn-success pull-right" style="margin-top: 5% !important;">Salvar</button>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>




                        <!--ALTERAÇÕES DA INDEX (FOOTER)-->
                        <div class="col-md-6">
                            <div class="box box-info">
                                <div class="box-header with-border">
                                    <div class="box-tools pull-right">
                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    </div>
                                </div>

                                <div class="box-body">
                                    <div class="row">

                                        <div class="col-md-12">
                                            <form id="fCat" class="form-horizontal" action="#" method="post">
                                                <button type="submit" class="btn btn-success pull-right" style="margin-top: 5% !important;">Salvar</button>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>



                        <!--ALTERAÇÕES DA INDEX (HEADER)-->
                        <div class="col-md-6">
                            <div class="box box-primary">
                                <div class="box-header with-border">
                                    <div class="box-tools pull-right">
                                        <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
                                    </div>
                                </div>


                                <div class="box-body">
                                    <div class="row">

                                        <div class="col-md-12">
                                            <form id="fCat" class="form-horizontal" action="#" method="post">
                                                <button type="submit" class="btn btn-success pull-right" style="margin-top: 5% !important;">Salvar</button>
                                            </form>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>


                    </section>
              </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>