<?php $__env->startSection('content'); ?>

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">

        <!-- Content Header (Page header) -->
        <section class="content-header">
            <h1>Produto</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
                <li class="active">Produto</li>
                <li><a href="#">Cadastro de produto</a></li>
            </ol>
        </section>

        <!-- Main content -->
        <section class="content">

            <?php echo $__env->make('partials.admin._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>


                <?php if($ultimoProduto == ""): ?>

                    <p>Não há produtos</p>

                    <?php endif; ?>

            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <h3 class="box-title">Cadastro de Produto</h3>
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i>
                        </button>
                    </div>

                </div>
                <div class="box-body">
                    
                        <form id="frmCadastroProduto" action="<?php echo e(route('productvariation.save')); ?>" method="post" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <!-- Nome do Produto (Modal) -->
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <div>
                                                <div class="form-group">
                                                    <label>Nome do Produto</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-cubes"></i></span>
                                                        <input type="text" class="form-control campo_nome_modal" name="nm_produto_variacao" value="<?php echo e($ultimoProduto[0]->nm_produto); ?>" maxlength="50">
                                                    </div>
                                                    <i class="msg_nome_prod"></i>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </table>

                                <!-- Códigos SKU e Ean (Modal) -->
                                <table style="width: 100%">
                                    <tr>
                                        <td style="width: 50%">
                                            <div>
                                                <div class="form-group">
                                                    <label>Código (SKU)</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-barcode"></i></span>
                                                        <input id="campo_sku" type="text" class="form-control campo_sku_modal" name="cd_sku_variacao" maxlength="20" value="<?php echo e($ultimoProduto[0]->cd_nr_sku); ?>" style="text-transform: uppercase">

                                                    </div>
                                                    <i class="msg_sku"></i>
                                                </div>
                                            </div>
                                        </td>

                                        <td>&nbsp;&nbsp;&nbsp;</td>

                                        <td style="width: 50%">
                                            <div>
                                                <div class="form-group">
                                                    <label>Código (EAN)</label>
                                                    <div class="input-group">
                                                        <span class="input-group-addon"><i class="fa fa-barcode"></i></span>
                                                        <input id="campo_ean" type="text" class="form-control campo_ean_modal" name="cd_ean_variacao" value="<?php echo e($ultimoProduto[0]->cd_ean); ?>" maxlength="13">
                                                    </div>
                                                    <i class="msg_ean"></i>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </table>

                                <!-- Categorias (Modal) -->
                                <table style="width: 100%">
                                    <tr>

                                        <input type="hidden" id="categorias" class="form-control select2 campo_cat_modal" style="width: 100%;" value="<?php echo e($ultimoProduto[0]->cd_categoria); ?>" name="cd_categoria_variacao">

                                        <input type="hidden" id="subcategorias" class="form-control select2 campo_subcat_modal" style="width: 100%;" value="<?php echo e($ultimoProduto[0]->cd_sub_categoria); ?>" name="cd_sub_categoria_variacao" >

                                        <input type="hidden" id="codProduto" class="form-control select2 campo_subcat_modal" style="width: 100%;" value="<?php echo e($ultimoProduto[0]->cd_produto); ?>" name="cd_produto_principal" >

                                        <input type="hidden" id="codEmbalagem" class="form-control select2 campo_subcat_modal" style="width: 100%;" value="<?php echo e($ultimoProduto[0]->cd_embalagem); ?>" name="cd_embalagem_variacao" >

                                    </tr>
                                </table>
                                <br>

                                <!-- Tamanhos (Modal) -->
                                <table style="width: 100%">
                                    <tr>
                                        <td style="width: 50%">
                                            <label>Tamanho (Letra)</label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                <select id="sl_tamanho_letra" class="form-control select2" style="width: 100%;" name="cd_tamanho_letra_variacao">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = $tamanhosLetras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tamanhoLetra): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($tamanhoLetra->cd_tamanho_letra); ?>"><?php echo e($tamanhoLetra->nm_tamanho_letra); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <i class="msg_tam_letra"></i>
                                        </td>

                                        <td>&nbsp;&nbsp;&nbsp;</td>

                                        <td style="width: 50%">
                                            <label>Tamanho (Número)</label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-list"></i></span>
                                                <select id="sl_tamanho_num" class="form-control select2" style="width: 100%;" name="cd_tamanho_num_variacao">
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = $tamanhosNumeros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tamanhoNumero): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($tamanhoNumero->cd_tamanho_num); ?>"><?php echo e($tamanhoNumero->nm_tamanho_num); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <i class="msg_tam_num"></i>
                                        </td>
                                    </tr>
                                </table>
                                <br>

                                <!-- Cor (Modal) -->
                                <table style="width: 100%">
                                    <tr>
                                        <td style="width: 51%">
                                            <label>Cor</label>
                                            <div class="input-group">
                                                <span class="input-group-addon"><i class="fa fa-paint-brush"></i></span>
                                                <select class="form-control select2" style="width: 100%;" name="cd_cor_variacao" >
                                                    <option value=""></option>
                                                    <?php $__currentLoopData = $cores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($cor->cd_cor); ?>"><?php echo e($cor->nm_cor); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <i class="msg_cor"></i>
                                        </td>

                                        <td>&nbsp;&nbsp;&nbsp;</td>

                                        <td style="width: 25%">
                                            <div>
                                                <label>Preço</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon">R$</span>
                                                    <input type="number" class="form-control campo_preco_modal" name="vl_produto_variacao" value="<?php echo e($ultimoProduto[0]->vl_produto); ?>" min="0">
                                                </div>
                                                <i class="msg_preco"></i>
                                            </div>
                                        </td>

                                        <td>&nbsp;&nbsp;&nbsp;</td>

                                        <td style="width: 25%">
                                            <div>
                                                <label>Quantidade</label>
                                                <div class="input-group">
                                                    <span class="input-group-addon">0-9</span>
                                                    <input type="number" class="form-control campo_qtd_modal" name="qt_produto_variacao" value="<?php echo e($ultimoProduto[0]->qt_produto); ?>" min="0">
                                                </div>
                                                <i class="msg_qtd"></i>
                                            </div>
                                        </td>
                                    </tr>
                                </table>
                                <br>

                                <!-- Descrição (Modal)  -->
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <div>
                                                <div class="form-group">
                                                    <label>Descrição do Produto</label>
                                                    <div class="input-group">
                                          <textarea id="bold" class="campo_desc_modal" name="ds_produto_variacao" rows="5" cols="112%" style="line-height: 40px; border: 1px solid #dddddd; padding: 2px; resize: none"  maxlength="1500">
                                              <?php echo e($ultimoProduto[0]->ds_produto); ?>

                                          </textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><p class="msg_desc"></p></td>
                                    </tr>
                                    <tr>
                                        <td><p><span class="qtd_palavras">1500</span> caracteres</p></td>
                                    </tr>
                                </table>

                                <!-- Imagens e Status (Modal) -->
                                <table style="width: 100%">
                                    <tr>
                                        <td>
                                            <div>
                                                <div>
                                                    <div class="form-group">
                                                        <label>Imagens</label>
                                                        <div class="input-group">
                                                            <div class="file-loading">
                                                                <input id="input-41" name="images_variacao[]" type="file" accept="image/*" multiple>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <div>
                                                <div class="box-header"><h3 class="box-title">Ativa/Desativar Produto</h3></div>
                                                <div class="box-body">
                                                    <div class="form-group">
                                                        <input type="checkbox" class="flat-red campo_status" name="status_variacao" checked>
                                                        <label class="">Status</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </table>

                                <!-- Botão Salvar (Modal) -->
                                <div style="width: 100%" class="text-right">
                                    <button type="submit" id="btn_salvar" class="btn btn-success"><i class="fa fa-save"></i>&nbsp;&nbsp;Salvar</button>
                                </div>
                        </form>

                </div>
                <!--<div class="box-footer">
                    Footer
                </div>-->
                <!-- /.box-footer-->
            </div>
        </section>
    </div>

    <script src="<?php echo e(asset('js/admin/jquery.cookie.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/nanobar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/jquery.blockUI.js')); ?>"></script>
    <script>

        //Chama a função de contagem de palavras ao carregar a página
        $(document).ready(function(){

           contadorPalavras();

        });

        //Validação do campo NOME DO PRODUTO
        $('.campo_nome').blur(function(){
            var campo = $(this).val();
            $('.msg_nome_prod').html("");

            if(campo.length == 0)
                $('.msg_nome_prod').html("Campo obrigatório.").css("color", "red");

            verificaAtributos();
        });

        //Validação do campo EAN
        $('#campo_ean').blur(function(){

            var campo = $('#campo_ean').val();
            var regra = /^[0-9]+$/;

            $('.msg_ean').html("");

            if(!campo.match(regra) && campo.length > 0){
                $('.msg_ean').html("Campo deve ser numérico").css("color", "red");
            }
            else if(campo.length < 13 && campo.length > 0) {
                $('.msg_ean').html("Campo deve conter 0 ou 13 caracteres.").css("color", "red");
            }

            verificaAtributos();
        });


        //Validação do campo SKU
        $('#campo_sku').blur(function() {

            var campo = $('#campo_sku').val();
            var regra = /^[a-zA-Z0-9]+$/;

            $('.msg_sku').html("");

            if (campo.length == 0) {
                $('.msg_sku').html("Campo obrigatório.").css("color", "red");
            }
            else if (!regra.exec(campo)) {
                $('.msg_sku').html("Proibido caracteres especiais.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo DESCRIÇÃO
        $('.campo_desc').blur(function() {

            var campo = $('.campo_desc').val();

            $('.msg_desc').html("");

            if (campo.length == 0) {
                $('.msg_desc').html("Campo obrigatório.").css("color", "red");
            }
            verificaAtributos();
        });

        //Validação do campo PREÇO
        $('.campo_preco').blur(function() {

            var campo = $('.campo_preco').val();

            $('.msg_preco').html("");

            if (campo.length == 0) {
                $('.msg_preco').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo CATEGORIA
        $('.campo_cat').blur(function() {

            var campo = $('.campo_cat').val();

            $('.msg_cat').html("");

            if (campo == "") {
                $('.msg_cat').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo CATEGORIA
        $('.campo_subcat').blur(function() {

            var campo = $('.campo_subcat').val();

            $('.msg_subcat').html("");

            if (campo == "") {
                $('.msg_subcat').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo QUANTIDADE
        $('.campo_qtd').blur(function() {

            var campo = $('.campo_qtd').val();

            $('.msg_qtd').html("");

            if (campo == "") {
                $('.msg_qtd').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo LARGURA
        $('.campo_largura').blur(function() {

            var campo = $('.campo_largura').val();

            $('.msg_largura').html("");

            if (campo == "") {
                $('.msg_largura').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo ALTURA
        $('.campo_altura').blur(function() {

            var campo = $('.campo_altura').val();

            $('.msg_altura').html("");

            if (campo == "") {
                $('.msg_altura').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });

        //Validação do campo PESO
        $('.campo_peso').blur(function() {

            var campo = $('.campo_peso').val();

            $('.msg_peso').html("");

            if (campo == "") {
                $('.msg_peso').html("Campo obrigatório.").css("color", "red");
            }

            verificaAtributos();
        });


        //Contagem de palavras na TextArea da Descrição
        function contadorPalavras() {

            $('.campo_desc').text("");

            $('.campo_desc').on("input", function () {
                var conteudo = $('.campo_desc').val();
                var qtdCaracter = 1500 - conteudo.length;


                $('.qtd_palavras').html(qtdCaracter);

            });
        };

        $('#sl_tamanho_letra').change(function (e) {

            e.preventDefault();

            $selValue = $(this).val();

            if ($selValue != "") {

                $('#sl_tamanho_num').val("");

            }

        });

        $('#sl_tamanho_num').change(function (e) {

            e.preventDefault();

            $selValue = $(this).val();

            if ($selValue != "") {

                $('#sl_tamanho_letra').val("");

            }

        });

        //Abrir o modal ao clicar no botão alterar
        // $('#btn_atributos').click(function(e){
        //     //e.preventDefault();
        //
        //     var my_cookie = $.cookie($('.modal-check').attr('name'));
        //     if (my_cookie && my_cookie == "true") {
        //         $(this).prop('checked', my_cookie);
        //         console.log('checked checkbox');
        //     }
        //     else{
        //         $('#myModal').modal('show');
        //         console.log('uncheck checkbox');
        //     }
        //
        //     $(".modal-check").change(function() {
        //         $.cookie($(this).attr("name"), $(this).prop('checked'), {
        //             path: '/',
        //             expires: 1
        //         });
        //     });
        //
        //     //mostrar os campos já digitados no cadastro de produtos dentro do modal
        //     $('.campo_nome_modal').val($('.campo_nome').val());
        //     $('.campo_desc_modal').val($('.campo_desc').val());
        //     $('.campo_ean_modal').val($('#campo_ean').val());
        //     $('.campo_sku_modal').val($('#campo_sku').val());
        //     $('.campo_preco_modal').val($('.campo_preco').val());
        //     $('.campo_qtd_modal').val($('.campo_qtd').val());
        //     $('.campo_largura_modal').val($('.campo_largura').val());
        //     $('.campo_altura_modal').val($('.campo_altura').val());
        //     $('.campo_peso_modal').val($('.campo_peso').val());
        //     $('.campo_cat_modal').val($('.campo_cat').val());
        //     $('.campo_subcat_modal').val($('.campo_subcat').val());
        //
        //     console.log($('.campo_cat_modal').val());
        //     console.log($('.campo_subcat_modal').val());
        //
        // });

        $('#btn_atributos').on('click', function (e) {
            e.preventDefault();

            $.ajax({

                url: '<?php echo e(url('/product')); ?>',
                type: 'POST',
                data: $('#frmCadastroProduto').serialize(),
                success: function () {

                    var my_cookie = $.cookie($('.modal-check').attr('name'));
                    if (my_cookie && my_cookie === 'true') {
                        $(this).prop('checked', my_cookie);
                        console.log('checked checkbox');
                    }
                    else{
                        $('#myModal').modal('show');
                        console.log('uncheck checkbox');
                    }

                    $(".modal-check").change(function() {
                        $.cookie($(this).attr("name"), $(this).prop('checked'), {
                            path: '/',
                            expires: 1
                        });
                    });

                    //mostrar os campos já digitados no cadastro de produtos dentro do modal
                    $('.campo_nome_modal').val($('.campo_nome').val());
                    $('.campo_desc_modal').val($('.campo_desc').val());
                    $('.campo_ean_modal').val($('#campo_ean').val());
                    $('.campo_sku_modal').val($('#campo_sku').val());
                    $('.campo_preco_modal').val($('.campo_preco').val());
                    $('.campo_qtd_modal').val($('.campo_qtd').val());
                    $('.campo_largura_modal').val($('.campo_largura').val());
                    $('.campo_altura_modal').val($('.campo_altura').val());
                    $('.campo_peso_modal').val($('.campo_peso').val());
                    $('.campo_cat_modal').val($('.campo_cat').val());
                    $('.campo_subcat_modal').val($('.campo_subcat').val());

                    console.log($('.campo_cat_modal').val());
                    console.log($('.campo_subcat_modal').val());

                }

            })

        });

        //Verifica botão Atributos
        function verificaAtributos(){
            var regra = /^[0-9]+$/;

            if ($('.campo_nome').val() != "" &&
                $('.campo_sku').val() != "" &&
                $('.campo_preco').val() != "" &&
                $('.campo_cat').val() != "" &&
                $('.campo_subcat').val() != "" &&
                $('.campo_qtd').val() != "" &&
                $('.campo_largura').val() != "" &&
                $('.campo_altura').val() != "" &&
                $('.campo_peso').val() != "" &&
                $('.campo_desc').val() != "" &&
                ($('.campo_ean').val().length == 0 ||
                ($('.campo_ean').val().length == 13 && regra.exec($('.campo_ean').val())))){
                $('#btn_atributos').removeAttr("disabled");
                $('#btn_salvar').removeAttr("disabled");
            }
            else {
                $('#btn_atributos').attr("disabled", "disabled");
                $('#btn_salvar').attr("disabled", "disabled");
            }

        }



    </script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>