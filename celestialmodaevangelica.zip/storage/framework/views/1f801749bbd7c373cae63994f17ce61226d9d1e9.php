<!DOCTYPE html>

<html lang="pt-br">

    <head>

        <?php echo $__env->make('partials.app._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body>

        <div id="wrapper">

            <?php echo $__env->make('partials.app._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php echo $__env->make('partials.app._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>

        <?php echo $__env->make('partials.app._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </body>

</html>