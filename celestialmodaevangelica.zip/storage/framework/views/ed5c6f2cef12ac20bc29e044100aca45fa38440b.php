<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

<title>CMEAdmin</title>

<!-- Favicon  -->
<link rel="icon" href="<?php echo e(asset('img/app/core-img/favicon.ico')); ?>">

<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

<?php echo $__env->make('partials.admin._styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php echo $__env->make('partials.admin._scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>