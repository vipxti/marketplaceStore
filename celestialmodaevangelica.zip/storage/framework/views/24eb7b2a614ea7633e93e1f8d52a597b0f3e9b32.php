<meta charset="UTF-8">
<meta name="description" content="">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<title>Celestial Moda Evangélica</title>

<!-- Favicon  -->
<link rel="icon" href="<?php echo e(asset('img/app/core-img/favicon.ico')); ?>">

<?php echo $__env->make('partials.app._styles', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>