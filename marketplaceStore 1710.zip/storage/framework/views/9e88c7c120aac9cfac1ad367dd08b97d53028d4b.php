<pre><?php echo e($msg); ?></pre>
<p>Email enviado por: <?php echo e($nome); ?> - <?php echo e($email); ?></p>