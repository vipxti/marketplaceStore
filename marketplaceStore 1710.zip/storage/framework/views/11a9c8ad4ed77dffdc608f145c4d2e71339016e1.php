<?php $__env->startSection('content'); ?>

    <style>
        .semestoque {
            width: 100%;
            margin: 0;
            font-size: 13px;
            font-weight: 700;
            color: #d59431;
            text-decoration: none
        }

        .btncomprar {
            width: 100%;
            margin: 0;
            font-size: 13px;
            font-weight: 700;
            color:#fff;
            background-color:#3a3a3a;
            text-decoration: none;
            border: none !important
        }

        .btnvariacao {
            width: 100% !important;
            height: 35px;
            padding-top: 7px;
            font-size: 13px;
            font-weight: 700 !important;
            color:#fff !important;
            background-color:#3a3a3a;
            text-decoration: none;
            border: none !important
        }

        .tamanhoimg {

            width: 255px;
            height: 255px;
            background-size: 100% 100%;
            -webkit-background-size: 100% 100%;
            -o-background-size: 100% 100%;
            -khtml-background-size: 100% 100%;
            -moz-background-size: 100% 100%;
        }

        .parcelas{
            color: #d59431;
        }

        .box span {
            position: absolute !important;
            top: 50% !important;
            left: 50% !important;
            transform: translate(-50%, -50%) !important;
        }

    </style>

    <link rel="stylesheet" href="<?php echo e(asset('css/app/magnific.css')); ?>">

    <section class="hero hero-home no-padding">
        <div class="owl-carousel owl-theme hero-slider">
            <!-- Banner 1 -->

            
            <?php $__currentLoopData = $banner; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div style="background: url(<?php echo e(asset('img/app/banner/' . $b->img_banner)); ?>); max-height: 535px !important;" class="item has-pattern" title="<?php echo e($b->titulo_banner); ?>">
                    <div class="container">
                        <div class="row" style="color: #fff">
                            <div class="col-lg-6">
                                <h1 style="color: #d59431;font-size: 2.0rem"></h1>
                                <ul class="lead">
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                    <p>&nbsp;</p>
                                </ul>
                                <p>&nbsp;</p>
                                <?php if($b->url_banner != null): ?>
                                    <a href="<?php echo e($b->url_banner); ?>" class="btn btn-template wide shop-now">Saiba Mais</a>
                                <?php endif; ?>
                                
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            <!-- Banner 2 -->
            

            <!-- Banner 3 -->
            
        </div>
    </section>

    <section class="new_arrivals_area section_padding_100_0 clearfix">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_heading text-center">
                        <img src="<?php echo e(asset('img/app/bg-img/novosprodutos.png')); ?>">
                    </div>
                </div>
            </div>
        </div>

        <div class="container">
            <div class="row karl-new-arrivals text-center">
                <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-4 col-md-3 single_gallery_item shoes">
                        <div class="product-img">
                            <img class="tamanhoimg" src="<?php echo e(URL::asset('img/products/' . $produto->im_produto)); ?>" alt="<?php echo e($produto->nm_slug); ?>">
                            <div class="product-quicview">
                                <a href="<?php echo e(route('products.details', $produto->nm_slug)); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>

                        <div class="product-description">
                            <h4 style="color: #dc3545" class="product-price">R$ <?php echo e(str_replace(".", ",", $produto->vl_produto)); ?></h4>
                            <p><b class="parcelas">3x</b> de <b class="parcelas">R$ <?php echo e(number_format(($produto->vl_produto/3), 2)); ?></b> sem juros </p>
                            <p style="max-height: 20px; text-overflow: ellipsis"><?php echo e($produto->nm_produto); ?></p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>

                            <?php if(array_key_exists($key, $arrayVariation)): ?>
                                <?php if($produto->qt_produto < 5): ?>
                                    <p class="semestoque">SEM ESTOQUE</p>
                                <?php else: ?>
                                    <div>
                                        <a class="btnvariacao box" href="<?php echo e(route('products.details', $produto->nm_slug)); ?>"><i class="icon-bag" aria-hidden="true"></i>&nbsp; COMPRAR</a>
                                    </div>
                                <?php endif; ?>
                            <?php else: ?>
                                <form action="<?php echo e(route('cart.buy')); ?>" method="post">
                                    <?php echo e(csrf_field()); ?>


                                    <input type="hidden" name="cd_produto" value="<?php echo e($produto->cd_produto); ?>">
                                    <input type="hidden" name="nm_produto" value="<?php echo e($produto->nm_produto); ?>">
                                    <input type="hidden" name="ds_produto" value="<?php echo e($produto->ds_produto); ?>">
                                    <input type="hidden" name="vl_produto" value="<?php echo e($produto->vl_produto); ?>">
                                    <input type="hidden" name="qt_produto" value="<?php echo e($produto->qt_produto); ?>">
                                    <input type="hidden" name="sku_produto" value="<?php echo e($produto->cd_nr_sku); ?>">
                                    <input type="hidden" name="slug_produto" value="<?php echo e($produto->nm_slug); ?>">
                                    <input type="hidden" name="ds_altura" value="<?php echo e($produto->ds_altura); ?>">
                                    <input type="hidden" name="ds_largura" value="<?php echo e($produto->ds_largura); ?>">
                                    <input type="hidden" name="ds_comprimento" value="<?php echo e($produto->ds_comprimento); ?>">
                                    <input type="hidden" name="ds_peso" value="<?php echo e($produto->ds_peso); ?>">
                                    <input type="hidden" name="im_produto" value="<?php echo e($produto->im_produto); ?>">
                                    <?php if($produto->qt_produto < 5): ?>
                                        <div>
                                            <p class="btn semestoque">SEM ESTOQUE</p>
                                        </div>
                                    <?php else: ?>
                                        <div>
                                            <button type="submit" class="btn btncomprar box" style="overflow: hidden"><i class="icon-bag" aria-hidden="true"></i>&nbsp;COMPRAR</button>
                                        </div>
                                    <?php endif; ?>
                                </form>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section class="categories">
        <div class="container">
            <header class="text-center">
                <h2 class="text-uppercase"><small>Produtos e Serviços</small></h2>
            </header>
            <div class="row text-left">
                <div class="col-lg-4"><a href="http://maktubbeauty.com.br/page/product/filter?search=Base+Liquida&id=pesquisa&catSubCat=Base+Liquida">
                        <div style="background-image: url(img/banner-1.png);" class="item d-flex align-items-end">
                            <div class="content">
                                <h3 class="h5">Base</h3><span>Coleções</span>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4"><a href="http://maktubbeauty.com.br/page/product/filter?id=s&catSubCat=53">
                        <div style="background-image: url(img/banner-2.png);" class="item d-flex align-items-end">
                            <div class="content">
                                <h3 class="h5">Paletas</h3><span>Novidades</span>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-lg-4"><a href="">
                        <div style="background-image: url(img/banner-3.png);" class="item d-flex align-items-end">
                            <div class="content">
                                <h3 class="h5">Queridinhos</h3><span>Parceiros</span>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <script src="<?php echo e(asset('js/app/magnific.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>