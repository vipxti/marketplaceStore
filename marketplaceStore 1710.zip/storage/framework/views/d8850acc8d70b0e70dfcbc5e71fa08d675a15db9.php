<!DOCTYPE html>

<html lang="pt-br">

    <head>

        <?php echo $__env->make('partials.app._head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body>
    <!-- Google Tag Manager (noscript) -->
    <noscript>
        <iframe src="https://www.googletagmanager.com/ns.html?id=GTM-K88JHSV" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    </noscript>
    <!-- End Google Tag Manager (noscript) -->
        <div id="wrapper">

            <?php echo $__env->make('partials.app._header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
            <?php echo $__env->yieldContent('content'); ?>
            
            <?php echo $__env->make('partials.app._footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        </div>

    </body>

</html>