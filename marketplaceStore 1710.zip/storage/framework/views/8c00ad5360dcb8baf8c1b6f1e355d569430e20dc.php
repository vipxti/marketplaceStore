<?php $__env->startSection('content'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">


    <div class="content-wrapper">
        <section class="content-header">
            <h1><i class="fa fa-list-alt"></i>&nbsp;&nbsp;Lista de Pedidos</h1>
            <ol class="breadcrumb">
                <li><a href="#"><i class="fa fa-dashboard"></i>Dashboard</a></li>
                <li><a href="#">Produtos</a></li>
                <li class="active">Lista de Pedidos</li>
            </ol>
        </section>

        <section class="content">
            <?php echo $__env->make('partials.admin._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <!-- Default box -->
            <div class="box box-primary">
                <div class="box-header with-border">
                    <div class="box-tools pull-right">
                        <button type="button" class="btn btn-box-tool" data-widget="collapse" data-toggle="tooltip" title="Collapse">
                            <i class="fa fa-minus"></i>
                        </button>
                        <button type="button" class="btn btn-box-tool" data-widget="remove" data-toggle="tooltip" title="Remove">
                            <i class="fa fa-times"></i>
                        </button>
                    </div>
                </div>
                <div class="box-body">
                   <a id="rotaPdf" href="" class="btn btn-danger pull-right"><i class="fa fa-file-pdf-o"></i>&nbsp;GERAR PDF</a>
                    <!-- Tabelas dos Pedidos -->
                    <table class="table" id="table">
                        <thead style="border-bottom: none !important;">
                            <tr>
                                <th style="text-align: left; border-bottom: none !important;"></th>
                                <th style="text-align: left; border-bottom: none !important;">Nº Pedido</th>
                                <th style="text-align: left; border-bottom: none !important;">Data</th>
                                <th style="text-align: left; border-bottom: none !important;">Destinatario</th>
                                <th style="text-align: left; border-bottom: none !important;">Código de Referência</th>
                                <th style="text-align: left; border-bottom: none !important;">Status</th>
                                <th style="text-align: left; border-bottom: none !important;">Ação</th>
                            </tr>
                        </thead>
                        <tbody id="tbodyTable">
                        <?php $__currentLoopData = $listOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <input type="checkbox" class="radionPDF" >
                                </td>
                                <td><?php echo e($order->cd_pedido); ?></td>
                                <td><?php echo e(date( 'd/m/Y' , strtotime($order->dt_compra))); ?></td>
                                <td><?php echo e(strtoupper($order->nm_destinatario)); ?></td>
                                <td><?php echo e(strtoupper($order->cd_referencia)); ?></td>
                                <td class="ext-center" style="width: 1% !important;">
                                    <?php switch($order->cd_status):
                                        case (1): ?>
                                        &nbsp;<i class="fa fa-circle-o text-yellow" title="Aguardando pagamento"></i>
                                        <?php break; ?>
                                        <?php case (2): ?>
                                        &nbsp;<i class="fa fa-circle-o text-blue" title="Em análise"></i>
                                        <?php break; ?>
                                        <?php case (3): ?>
                                        &nbsp;<i class="fa fa-circle-o text-green" title="Paga"></i>
                                        <?php break; ?>
                                        <?php case (4): ?>
                                        &nbsp;<i class="fa fa-circle-o text-green" title="Disponível"></i>
                                        <?php break; ?>
                                        <?php case (5): ?>
                                        &nbsp;<i class="fa fa-circle-o text-blue" title="Em disputa"></i>
                                        <?php break; ?>
                                        <?php case (6): ?>
                                        &nbsp;<i class="fa fa-circle-o text-blue" title="Devolvida"></i>
                                        <?php break; ?>
                                        <?php case (7): ?>
                                        &nbsp;<i class="fa fa-circle-o text-red" title="Reprovado"></i>
                                        <?php break; ?>
                                    <?php endswitch; ?>
                                </td>
                                <td>
                                    <button id="btnOrder" class="btn btn-default mt-0 mb-0 p-0" onclick="vIdBtn(<?php echo e($order->cd_pedido); ?>)" data-toggle="modal" data-target="#modal-default">
                                        <i class="fa fa-eye"></i>
                                    </button>
                                    <button class="btnPrintList btn btn-default mt-0 mb-0 p-0" value="<?php echo e($order->cd_pedido); ?>"><i class="fa fa-print"></i></button>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <div align="center">
                        <?php echo e($listOrder->links()); ?>

                    </div>

                    <!--modal Pedido-->
                        <div class="modal fade bd-example-modal-lg" id="modal-default">
                        <div class="modal-dialog modal-lg">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span id="closeModal" aria-hidden="true">&times;</span></button>
                                    <h4 class="modal-title">Pedido&nbsp;<small id="nPedido"></small></h4>
                                </div>
                                <div class="modal-body" style="padding: 25px !important;">
                                    

                                    <!-- Main content -->
                                    <!-- title row -->
                                    <div class="row">
                                        <div class="col-xs-12">
                                            <h2 class="page-header">
                                                <img id="imLogo" style="margin-left:1.5%; width:112px; height:112px;" src="" alt="">
                                                <small class="pull-right">
                                                    <div id="dtCompra"></div>
                                                    <br>
                                                    <h5 id="statusPedido" class="pull-right"></h5>
                                                </small>
                                                <p id="nmLogoFantasia"></p>
                                            </h2>

                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- info row -->
                                    <div class="row invoice-info">
                                        <div class="col-sm-4 invoice-col">
                                            DE
                                            <address>
                                                <strong ><b id="nmFantasia"></b></strong>
                                                <div>Cnpj:&nbsp;<small id="eCnpj"></small></div>
                                                <small id="dsEndereco"></small>,&nbsp;nº<small id="nEnd"></small>&nbsp;-&nbsp;<small id="dsComplemento"></small>
                                                <small id="nmBairro"></small>,<br><small id="nmCidade"></small>&nbsp;-&nbsp;<small id="sgUf"></small>
                                                &nbsp;/&nbsp;Cep:&nbsp;<small id="eCep"></small>
                                                <div>Telefone:&nbsp;<small id="ePhone"></small></div>
                                            </address>
                                        </div>
                                        <!-- /.col -->
                                        <div class="col-sm-4 invoice-col">
                                            PARA
                                            <address>
                                                <strong><b id="cNmDestinatario"></b></strong><br>
                                                <small id="cDsEndereco"></small>,&nbsp;nº<small id="cNumeroEndereco"></small><br><small id="cComplemento"></small>&nbsp;-&nbsp;<small id="cDsPontoReferencia"></small><br>
                                                <small id="cNmBairro"></small>,&nbsp;<small id="cNmCidade"></small>&nbsp;-&nbsp;<small id="cSgUf"></small>
                                                &nbsp;/&nbsp;Cep:&nbsp;<small id="cCep"></small>
                                                <div>Telefone:&nbsp;<small id="cCelular1"></small></div>
                                                E-Mail:&nbsp;<small id="cEmail"></small>
                                            </address>
                                        </div>
                                        <!-- /.col -->
                                        <div class="col-sm-4 invoice-col">
                                            <div><b>Cód. PagSeguro:</b>&nbsp;<small id="cdPagseguro" ></small></div>
                                            <div><b>Cód. Trasação:</b>&nbsp;<small id="cdReferencia" ></small></div>
                                            <div><b>Nº Pedido:</b>&nbsp;<small id="cPedido" ></small></div>
                                            <b>Data de Pagamento:</b>&nbsp;<small id="dtAlteracao"></small><br>
                                            <b>Usuário:</b>&nbsp;<small id="cNmCliente"></small>
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->

                                    <!-- Table row -->
                                    <div class="row">
                                        <div class="col-xs-12 table-responsive">
                                            <p class="lead">Itens da Venda</p>
                                            <table id="project-table" class="table table-striped">
                                                <thead>
                                                    <tr>
                                                        <th>Código</th>
                                                        <th>Ean</th>
                                                        <th>Sku</th>
                                                        <th>Qtd</th>
                                                        <th>Nome do Produto</th>
                                                        <th>Un</th>
                                                        <th>Total</th>
                                                    </tr>
                                                </thead>
                                                <tbody id="tbodyPedidos"></tbody>
                                            </table>
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->

                                    <div class="row">
                                        <!-- accepted payments column -->
                                        
                                        <!-- /.col -->
                                        <div class="col-xs-12">
                                            <p class="lead">Resumo dos Valores:</p>
                                            <div class="table-responsive">
                                                <table class="table">
                                                    <tr>
                                                        <th style="width:50%">Sub Total:</th>
                                                        <td id="vlSTotal"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Frete:</th>
                                                        <td id="vlFrete"></td>
                                                    </tr>
                                                    <tr>
                                                        <th>Total:</th>
                                                        <td id="vlTotal"></td>
                                                    </tr>
                                                </table>
                                            </div>
                                        </div>
                                        <!-- /.col -->
                                    </div>
                                    <!-- /.row -->

                                    <!-- this row will not appear when printing -->
                                    <div class="row no-print">
                                        <div class="col-xs-12">
                                            <button id="btnPrint" class="btn btn-default" value=""><i class="fa fa-print"></i>&nbsp;Imprimir</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.modal-content -->
                        </div>
                        <!-- /.modal-dialog -->
                    </div>
                    <!-- /.modal -->
                </div>
            </div>
        </section>
    </div>

    <script src="<?php echo e(asset('js/admin/jquery.cookie.js')); ?>"></script>
    <script>
        const CSRF_TOKEN = $('meta[name="csrf-token"]').attr('content');

        //ENVIA ARRAY CO ID PRA IMPRESSÃO
        let arrayPedidos = [];
        function ajaxCountTable(tableRow){
            let tamanhoTable = $('#table tr').length;
            if(tableRow <= tamanhoTable) {
                if($('#tbodyTable tr:eq(' + tableRow + ')>td:first').find('.radionPDF').is(':checked')){
                    arrayPedidos.push($('#tbodyTable tr:eq(' + tableRow + ')>td:eq(1)').text());
                }
                ajaxCountTable(++tableRow);
            }
            else{
                $('#rotaPdf').prop('href', '<?php echo e(url('admin/pedido/dynamic_pdf/pdf/')); ?>' + '/' + arrayPedidos);
            }
        }

        $('#mostraPdf').click(function(){
            ajaxCountTable(0);
        });

        $('.radionPDF').click(function(){
           if($(this).is(':checked')){
               arrayPedidos.push($(this).parent().parent().find('td:eq(1)').text());
           }
           else{
               if(arrayPedidos.includes($(this).parent().parent().find('td:eq(1)').text())){
                   let itemtoRemove = $(this).parent().parent().find('td:eq(1)').text();
                   arrayPedidos.splice($.inArray(itemtoRemove, arrayPedidos),1);
               }
           }
            $('#rotaPdf').prop('href', '<?php echo e(url('admin/pedido/dynamic_pdf/pdf/')); ?>' + '/' + arrayPedidos);
        });

        function print(id) {
            window.open('<?php echo e(url('admin/pedido/print/')); ?>' + '/' + id, '_blank');
        }

        $('#btnPrint').click(function(){
            print($(this).val());
        });
        $('button.btnPrintList').click(function(){
            print($(this).val());
        });

        function vIdBtn(id){
            $('#tbodyPedidos').empty();
            let idOder = id;

            $.ajax({
                url: '<?php echo e(route('order.modal.list')); ?>',
                type: 'post',
                data: {_token: CSRF_TOKEN, idOder: idOder},
                success: function(data){
                    // DADDOS DA EMPRESA
                    $("#nmLogoFantasia").html(data.dadosPedido.original.dadosEmpresa.nm_fantasia);
                    $("#nmFantasia").html(data.dadosPedido.original.dadosEmpresa.nm_fantasia);
                    $("#eCep").html(data.dadosPedido.original.eCep);
                    $("#eCnpj").html(data.dadosPedido.original.eCnpj);
                    $("#ePhone").html(data.dadosPedido.original.ePhone);
                    $("#nEnd").html(data.dadosPedido.original.dadosEmpresa.cd_numero_endereco);
                    $("#dsComplemento").html(data.dadosPedido.original.dadosEmpresa.ds_complemento);
                    $("#dsEndereco").html(data.dadosPedido.original.dadosEmpresa.ds_endereco);
                    $("#nmBairro").html(data.dadosPedido.original.dadosEmpresa.nm_bairro);
                    $("#nmCidade").html(data.dadosPedido.original.dadosEmpresa.nm_cidade);
                    $("#sgUf").html(data.dadosPedido.original.dadosEmpresa.sg_uf,);
                    $("#imLogo").attr("src", '/img/company/' + data.dadosPedido.original.dadosEmpresa.im_logo);

                    // DADDOS Do CLIENTE
                    $("#cNmDestinatario").html(data.dadosPedido.original.dadosCliente.nm_destinatario);
                    $("#cNmCliente").html(data.dadosPedido.original.dadosCliente.nm_cliente);
                    $("#cCelular1").html(data.dadosPedido.original.dadosCliente.cd_celular1);
                    $("#cCep").html(data.dadosPedido.original.dadosCliente.cd_cep);
                    $("#cCpfCnpj").html(data.dadosPedido.original.dadosCliente.cd_cpf_cnpj);
                    $("#cNumeroEndereco").html(data.dadosPedido.original.dadosCliente.cd_numero_endereco);
                    $("#cComplemento").html(data.dadosPedido.original.dadosCliente.ds_complemento);
                    $("#cDsEndereco").html(data.dadosPedido.original.dadosCliente.ds_endereco);
                    $("#cDsPontoReferencia").html(data.dadosPedido.original.dadosCliente.ds_ponto_referencia);
                    $("#cEmail").html(data.dadosPedido.original.dadosCliente.email);
                    $("#cNmBairro").html(data.dadosPedido.original.dadosCliente.nm_bairro);
                    $("#cNmCidade").html(data.dadosPedido.original.dadosCliente.nm_cidade);
                    $("#cSgUf").html(data.dadosPedido.original.dadosCliente.sg_uf);

                    //DADOS DO PEDIDO
                    let stPedido = data.dadosPedido.original.dadosCliente.cd_status;
                    let strPedido = "";
                    let subTotal = (data.dadosPedido.original.dadosCliente.vl_total - data.dadosPedido.original.dadosCliente.vl_frete);

                    switch(stPedido) {
                        case 1:
                            strPedido = ('Aguardando pagamento');
                            $("#statusPedido").html(strPedido);
                            break;
                        case 2:
                            strPedido =('Em análise');
                            $("#statusPedido").html(strPedido);
                            break;
                        case 3:
                            strPedido =('Paga');
                            $("#statusPedido").html(strPedido);
                            break;
                        case 4:
                            strPedido =('Disponível');
                            $("#statusPedido").html(strPedido);
                            break;
                        case 5:
                            strPedido =('Em disputa');
                            $("#statusPedido").html(strPedido);
                            break;
                        case 6:
                            strPedido =('Devolvida');
                            $("#statusPedido").html(strPedido);
                            break;
                        case 7:
                            strPedido =('Reprovado');
                            $("#statusPedido").html(strPedido);
                            break;
                        default:
                            strPedido =("ERRO!!");
                            $("#statusPedido").html(strPedido);
                    }

                    $("#nPedido").html('Nº#' + data.dadosPedido.original.dadosCliente.cd_pedido);
                    $("#cPedido").html('#' + data.dadosPedido.original.dadosCliente.cd_pedido);
                    $("#cdReferencia").html(data.dadosPedido.original.dadosCliente.cd_referencia);
                    $("#cdPagseguro").html(data.dadosPedido.original.dadosCliente.cd_pagseguro);
                    //

                    let dt_compra = data.dadosPedido.original.dadosCliente.dt_compra;
                    let dateComprar = dt_compra.split('-');
                    let novaDatacompra = dateComprar[2] + '/' + dateComprar[1] + '/' + dateComprar[0];

                    $("#dtCompra").html('Data de Emissão ' + novaDatacompra);


                    let dt_alteracao = data.dadosPedido.original.dadosCliente.dt_alteracao;
                    let dateAr = dt_alteracao.split('-');
                    let novaData = dateAr[2] + '/' + dateAr[1] + '/' + dateAr[0];

                    $("#dtAlteracao").html(novaData);

                    $("#vlSTotal").html('R$ ' + subTotal.toFixed(2).replace('.',","));
                    $("#vlFrete").html('R$ ' + data.dadosPedido.original.dadosCliente.vl_frete.replace('.',","));
                    $("#vlTotal").html('R$ ' + data.dadosPedido.original.dadosCliente.vl_total.replace('.',","));

                    //IMPRESSAO DO PEDIDO
                    $("#btnPrint").val(data.dadosPedido.original.dadosCliente.cd_pedido);


                    let pedProd = data.dadosPedido.original.prductsOders;
                    $.each( pedProd, function( key, value ) {
                        let precoQTD = (data.dadosPedido.original.prductsOders[key].qt_produto * data.dadosPedido.original.prductsOders[key].vl_produto);
                        console.log(data.dadosPedido.original.prductsOders[key].qt_produto );
                        console.log(data.dadosPedido.original.prductsOders[key].vl_produto);
                        $('#project-table>tbody').append(
                            $("<tr>").append(
                                $("<td>").append(value.cd_produto),
                                $("<td>").append(value.cd_ean),
                                $("<td>").append(value.cd_nr_sku),
                                $("<td>").append(value.qt_produto),
                                $("<td>").append(value.nm_produto),
                                $("<td>").append(value.vl_produto.replace('.',",")),
                                $("<td>").append(precoQTD.toString().replace('.',",")),
                            )
                        )
                    });

                    let pedProdVariacao = data.dadosPedido.original.prductsOdersVariacao;
                    $.each( pedProdVariacao, function( key, value ) {
                        let sbToal = (data.dadosPedido.original.prductsOdersVariacao[key].qt_produto * data.dadosPedido.original.prductsOdersVariacao[key].vl_produto_variacao);
                        $('#project-table>tbody').append(
                            $("<tr>").append(
                                $("<td>").append(value.cd_produto_variacao),
                                $("<td>").append(value.cd_ean_variacao),
                                $("<td>").append(value.cd_nr_sku),
                                $("<td>").append(value.qt_produto),
                                $("<td>").append(value.nm_produto_variacao),
                                $("<td>").append(value.vl_produto_variacao.replace('.', ",")),
                                $("<td>").append(sbToal.toString().replace('.', ","))
                            )
                        )
                    });
                }
            });
        }
    </script>
    <!-- SlimScroll -->
    <script src="<?php echo e(asset('js/admin/jquery.slimscroll.min.js')); ?>"></script>
    <!-- FastClick -->
    <script src="<?php echo e(asset('js/admin/fastclick.js')); ?>"></script>
    <!-- page script -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>