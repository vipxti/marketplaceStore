<footer class="main-footer">

    <div class="pull-right hidden-xs">

        <b>Vesion</b> 1.0

    </div>

    <strong>Copyright &copy; 2018 <a href="#">VipX Marketplace</a>.</strong> Todos os direitos reservados.

</footer>