@extends('layouts.app.app')

@section('content')
    
    <div class="container">

        <div class="row">

            <div class="col">

                <p>&nbsp;</p>

                <p class="h2 d-flex justify-content-center">Página não encontrada</p>

                <p>&nbsp;</p>

            </div>

        </div>

    </div>

@stop