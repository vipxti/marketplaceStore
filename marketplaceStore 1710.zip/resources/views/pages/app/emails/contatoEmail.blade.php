<pre>{{$msg}}</pre>
<p>Email enviado por: {{$nome}} - {{$email}}</p>