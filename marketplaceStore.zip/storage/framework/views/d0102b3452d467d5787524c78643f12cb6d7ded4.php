<?php $__env->startSection('content'); ?>


    <div class="login-box">
    <?php echo $__env->make('partials.admin._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/admin/_all.css')); ?>">

        <div class="login-box-body">
            <p class="login-box-msg">Entre para iniciar sua sessão</p>

            <form action="<?php echo e(route('admin.login.submit')); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group has-feedback">
                    <input type="email" class="form-control" name="email" placeholder="Email" required maxlength="35">
                    <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                </div>
                <div class="form-group has-feedback">
                    <input type="password" class="form-control" name="password" placeholder="Senha" required minlength="6">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                </div>
                
                <div class="row">
                    <div class="col-xs-12">
                        <button type="submit" class="btn btn-primary btn-block btn-flat">Entrar</button>
                    </div>
                </div>
            </form>

            

            <br>
            

        </div>
    </div>

    <script src="<?php echo e(asset('js/admin/icheck.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/admin/jquery.inputmask.js')); ?>"></script>
    <script>
        $(function(){
            //Flat red color scheme for iCheck
            $('input[type="checkbox"].flat-red, input[type="radio"].flat-red').iCheck({
                checkboxClass: 'icheckbox_flat-blue'
            })
        })
    </script>

<?php $__env->stopSection(); ?>






<?php echo $__env->make('layouts.admin.panel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>