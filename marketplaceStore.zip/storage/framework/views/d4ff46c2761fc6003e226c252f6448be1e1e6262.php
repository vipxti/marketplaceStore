<?php if(session('success')): ?>

    <div class="alert alert-success text-center msg" role="alert">

        <?php echo e(session('success')); ?>


    </div>

<?php endif; ?>

<?php if(session('nosuccess')): ?>

    <div class="alert alert-danger text-center msg" role="alert">

        <?php echo e(session('nosuccess')); ?>


    </div>

<?php endif; ?>

<?php if(count($errors)): ?>

    <div class="form-group">

        <div class="alert alert-danger msg text-center" role="alert">

            <ul>

                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li><?php echo e($error); ?></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </ul>

        </div>

    </div>

<?php endif; ?>

<script>

    setTimeout(function() {

        $('.msg').fadeOut('slow');

        }, 4000);

</script>