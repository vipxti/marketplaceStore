<meta charset="utf-8">

<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="csrf-token" content="{{ csrf_token() }}">

<title>CMEAdmin</title>

<!-- Favicon  -->
<link rel="icon" href="{{ asset('img/app/core-img/favicon.ico') }}">

<!-- Tell the browser to be responsive to screen width -->
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

@include('partials.admin._styles')

@include('partials.admin._scripts')