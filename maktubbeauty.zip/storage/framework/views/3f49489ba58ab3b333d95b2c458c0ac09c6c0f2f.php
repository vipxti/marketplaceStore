<?php $__env->startSection('content'); ?>
    
    <div class="container">

        <div class="row">

            <div class="col">

                <p>&nbsp;</p>

                <p class="h2 d-flex justify-content-center">Página não encontrada</p>

                <p>&nbsp;</p>

            </div>

        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>