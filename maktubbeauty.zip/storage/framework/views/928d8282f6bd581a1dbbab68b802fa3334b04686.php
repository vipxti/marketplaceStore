<!DOCTYPE html>

<html lang="pt-br">

    <head>

        <?php echo $__env->make('partials.admin._headpanel', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </head>

    <body class="hold-transition login-page">

        <div class="top_logo" align="center">

            <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('img/app/core-img/logo1.png')); ?>" alt="" style="width: 175px !important; height: 100px !important; margin: 3% 0 -4% 0 !important"></a>

        </div>

        <?php echo $__env->yieldContent('content'); ?>

        <!-- jQuery 3 -->


    </body>

</html>
