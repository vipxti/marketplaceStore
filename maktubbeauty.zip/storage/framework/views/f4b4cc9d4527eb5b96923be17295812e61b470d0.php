<?php $__env->startSection('content'); ?>

    <div class="container" STYLE="margin-bottom: 3.5%;">
        <div class="row" style="margin-top: 2.5%;">
            <?php echo $__env->make('partials.admin._alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="col-12 col-md-12">
                <p class="h4 text-center">Detalhes da sua compra</p>
            </div>

            <div class="col-12 col-md-12" >
                <div class="cart-table clearfix table-responsive">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>Produto</th>
                            <th>Quantidade</th>
                            <th>Valor</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr>
                                <td class="cart_product_img d-flex align-items-center align-middle">
                                    <a href="javascipt:void(0);">
                                        <img src="<?php echo e(URL::asset('img/products' . '/' . $produto['imagemProduto'])); ?>" alt="Product">
                                    </a>
                                    <p style="font-size: 14px;"><?php echo e($produto['nomeProduto']); ?></p>
                                </td>
                                <td class="qty align-middle text-center">
                                    <div class="quantity">
                                        <span><?php echo e($produto['qtdIndividual']); ?></span>
                                    </div>
                                </td>
                                <td class="price align-middle align-items-center">
                                    <span id="<?php echo e('precoTotalProd' . $key); ?>">
                                        R$ <?php echo e(number_format($produto['valorTotalProduto'], 2, ',', '.')); ?>

                                    </span>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <?php if($shippingData[0]['tipo'] == 1): ?>
                                <td class="text-right" colspan="2"><b>FRETE ESCOLHIDO:</b> PAC</td>
                                <td class="price align-middle align-items-center">
                                    <span id="precoFrete">
                                        R$ <?php echo e(number_format(($shippingData[0]['valor']), 2, ',', '.')); ?>

                                    </span>
                                </td>
                            <?php elseif($shippingData[0]['tipo'] == 2): ?>
                                <td class="text-right" colspan="2"><b>FRETE ESCOLHIDO:</b></b> SEDEX</td>
                                <td class="price align-middle align-items-center">
                                    <span id="precoFrete">
                                        R$ <?php echo e(number_format(($shippingData[0]['valor']), 2, ',', '.')); ?>

                                    </span>
                                </td>
                            <?php else: ?>
                                <td class="text-right" colspan="2"><b>FRETE ESCOLHIDO:</b></b> ENTREGA VIP-X</td>
                                <td class="price align-middle align-items-center">
                                    <span id="precoFrete">
                                        R$ <?php echo e(number_format(($shippingData[0]['valor']), 2, ',', '.')); ?>

                                    </span>
                                </td>
                            <?php endif; ?>
                        </tr>
                        <?php if($paymentType == 'cartao'): ?>
                            <?php if($creditCardInfo[0]['installmentQuantity'] > 3): ?>
                                <tr>
                                    <td class="text-right" colspan="2"><b>JUROS PARCELAMENTO:</b></td>
                                    <td class="price align-middle align-items-center">
                                        <span id="precoJuros">
                                            R$ <?php echo e(number_format(($creditCardInfo[0]['totalAmount'] - Session::get('totalPrice')) , 2, ',', '.')); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endif; ?>
                            <tr>
                                <td class="text-right" colspan="2"><strong>TOTAL</strong></td>
                                <td class="total_price align-middle">
                                    <span id="valorTotal">
                                        <strong>R$ <?php echo e(number_format($creditCardInfo[0]['totalAmount'], 2, ',', '.')); ?></strong>
                                    </span>
                                </td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td class="text-right" colspan="2"><strong>TOTAL</strong></td>
                                <td class="total_price align-middle">
                                    <span id="valorTotal">
                                        
                                        <strong>R$ <?php echo e(number_format(\Illuminate\Support\Facades\Session::get('totalPrice'), 2, ',', '.')); ?></strong>
                                    </span>
                                </td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

            <div class="col-12 col-md-12">
                <div class="col-11 col-md-11">
                    <?php if($paymentType == 'boleto'): ?>
                        <p><b>FORMA DE PAGAMENTO:</b>&nbsp;BOLETO BANCÁRIO</p>
                    <?php else: ?>
                        <?php if($creditCardInfo[0]['installmentQuantity'] > 3): ?>
                            <p>Forma de pagamento: <?php echo e($creditCardInfo[0]['installmentQuantity']); ?>x com juros no cartão de crédito (R$&nbsp;<?php echo e(number_format($creditCardInfo[0]['totalAmount'], 2, ',', '.')); ?>)</p>
                        <?php else: ?>
                            <p>Forma de pagamento: <?php echo e($creditCardInfo[0]['installmentQuantity']); ?>x sem juros no cartão de crédito (R$&nbsp;<?php echo e(number_format($creditCardInfo[0]['totalAmount'], 2, ',', '.')); ?>)</p>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-12 col-md-12">
                <div class="col-12 col-md-12">
                    <a href="<?php echo e(route('cart.page')); ?>" class="btn btn-template pull-left">Revisar pedido</a>
                    <?php if($paymentType == 'boleto'): ?>
                        <form action="<?php echo e(route('payment.ticket')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" class="senderHash" name="senderHash" value="">
                            <input type="hidden" name="cd_cliente" value="<?php echo e(Auth::user()->cd_cliente); ?>">
                            <button id="btn_finalizar" type="submit" class="btn btn-template pull-right" disabled>Finalizar Compra</button>
                        </form>
                    <?php else: ?>
                        <form action="<?php echo e(route('payment.creditcard')); ?>" method="post">
                            <?php echo e(csrf_field()); ?>

                            <input type="hidden" class="senderHash" name="senderHash" value="">
                            <input type="hidden" name="cardToken" value="<?php echo e($creditCardInfo[0]['cardToken']); ?>">
                            <input type="hidden" name="cd_cliente" value="<?php echo e(Auth::user()->cd_cliente); ?>">
                            <button id="btn_finalizar" type="submit" class="btn btn-template pull-right" disabled>Finalizar Compra</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        $(function () {
            PagSeguroDirectPayment.onSenderHashReady(function(response){
                if(response.status == 'error') {
                    return false;
                }
                $('.senderHash').val(response.senderHash)
                $('#btn_finalizar').removeAttr('disabled');
            });

            $('#btn_finalizar').click(function(e){
                //e.preventDefault();
            });

            
        })
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>