<?php $__env->startSection('content'); ?>
        <section class="shop_grid_area section_padding_100">
        <div class="container">
            <div class="row">
                <!-- Produtos e Contador páginas -->
                <div class="col-12 col-md-8 col-lg-12 d-flex justify-content-center">
                    <div class="row">
                        <div class="row karl-new-arrivals text-center">
                            <?php if(count($produtoCatSubCat) == 0): ?>
                                <h5 style="text-align: center !important; margin: 60px 0 60px 0 !important;">NÃO HÁ PRODUTOS NESSA CATEGORIA</h5>
                            <?php else: ?>
                                <?php $__currentLoopData = $produtoCatSubCat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-12 col-sm-4 col-md-3 single_gallery_item">
                                        <div class="product-img img-fluid mx-auto d-block" >
                                            <img class="w-100 mx-auto d-block" style="width: 285px !important; height: 375px !important;" src="<?php echo e(URL::asset('img/products' . '/' . $produto->im_produto)); ?>" alt="">
                                            <div class="product-quicview">
                                                <a href="<?php echo e(route('products.details', $produto->nm_slug)); ?>"><i class="ti-plus"></i></a>
                                            </div>
                                        </div>

                                        <div class="product-description" style="padding: 0 5%">
                                            <h4 class="product-price">R$ <?php echo e(str_replace(".", ",", $produto->vl_produto)); ?></h4>
                                            <p style="min-height: 66px !important;"><?php echo e($produto->nm_produto); ?></p>
                                            <!-- Botão comprar -->
                                            <form action="<?php echo e(route('cart.buy')); ?>" method="post">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="cd_produto" value="<?php echo e($produto->cd_produto); ?>">
                                                <input type="hidden" name="nm_produto" value="<?php echo e($produto->nm_produto); ?>">
                                                <input type="hidden" name="ds_produto" value="<?php echo e($produto->ds_produto); ?>">
                                                <input type="hidden" name="vl_produto" value="<?php echo e($produto->vl_produto); ?>">
                                                <input type="hidden" name="qt_produto" value="<?php echo e($produto->qt_produto); ?>">
                                                <input type="hidden" name="sku_produto" value="<?php echo e($produto->cd_nr_sku); ?>">
                                                <input type="hidden" name="slug_produto" value="<?php echo e($produto->nm_slug); ?>">
                                                <input type="hidden" name="ds_altura" value="<?php echo e($produto->ds_altura); ?>">
                                                <input type="hidden" name="ds_largura" value="<?php echo e($produto->ds_largura); ?>">
                                                <input type="hidden" name="ds_comprimento" value="<?php echo e($produto->ds_comprimento); ?>">
                                                <input type="hidden" name="ds_peso" value="<?php echo e($produto->ds_peso); ?>">
                                                <input type="hidden" name="im_produto" value="<?php echo e($produto->im_produto); ?>">
                                                <?php if($produto->qt_produto < 5): ?>
                                                    <p class="btn" style="width:100%; margin: 0; font-size: 13px; font-weight: 700; color:#3a3a3a; background-color:#f5f5f5; text-decoration: none;">SEM ESTOQUE</p>
                                                <?php else: ?>
                                                    <button type="submit" class="btn" style=" width:100%; margin: 0; font-size: 13px; font-weight: 700; color:#3a3a3a; background-color:#f5f5f5; text-decoration: none; border: none !important;"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp; COMPRAR</button>
                                                <?php endif; ?>
                                            </form>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!-- jQuery (Necessary for All JavaScript Plugins) -->
    <script src="js/jquery/jquery-2.2.4.min.js"></script>
    <!-- Popper js -->
    <script src="js/popper.min.js"></script>
    <!-- Bootstrap js -->
    <script src="js/bootstrap.min.js"></script>
    <!-- Plugins js -->
    <script src="js/plugins.js"></script>
    <!-- Active js -->
    <script src="js/active.js"></script>

    <script>

        $('#quickview').on('show', function (e) {

            var link = e.relatedTarget(),
                $modal = $(this)

            console.log($modal);

        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>