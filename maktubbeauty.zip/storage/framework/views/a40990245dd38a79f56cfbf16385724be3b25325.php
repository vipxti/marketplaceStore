<?php $__env->startSection('content'); ?>

        <!-- Política de privacidade -->
        <section id="policies" class="policies-section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <h3 style="color: #d59431">Política de privacidade</h3>
                        <p>&nbsp;</p>
                        <p class="text-justify">A Maktub Beauty sempre estará preocupada em proteger seus dados com segurança e privacidade.
                            Os seus dados cadastrais são armazenados de forma segura e sigilosa. Todos seus dados serão utilizados somente autorizado. No final da Pagina (rodapé) toda comunicação de newsletter você encontrará a opção "descadastro" na qual poderá optar por não receber as nossas promoções.
                            Qualquer duvida só entrar em contato conosco através de nossas redes sociais
                        </p>
                    </div>
                </div>
            </div>
        </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>