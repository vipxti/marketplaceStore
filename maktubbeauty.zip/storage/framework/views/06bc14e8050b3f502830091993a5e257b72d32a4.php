<?php $__env->startSection('content'); ?>

    <style>
        .semestoque {
            width: 100%;
            margin: 0;
            font-size: 13px;
            font-weight: 700;
            color: #d59431;
            text-decoration: none
        }

        .btncomprar {
            width:100%;
            margin: 0;
            font-size: 13px;
            font-weight: 700;
            color:#fff;
            background-color:#3a3a3a;
            text-decoration: none;
            border: none !important
        }

        .tamanhoimg {

            width: 255px;
            height: 255px;
            background-size: 100% 100%;
            -webkit-background-size: 100% 100%;
            -o-background-size: 100% 100%;
            -khtml-background-size: 100% 100%;
            -moz-background-size: 100% 100%;
        }

    </style>

    <link rel="stylesheet" href="<?php echo e(asset('css/app/magnific.css')); ?>">

    <!-- Banner Principal-->
    <section class="hero hero-home no-padding">
        <div class="owl-carousel owl-theme hero-slider">
            <!-- Banner 1 -->
            <div style="background: url(<?php echo e(asset('img/app/bg-img/hero-bg.png')); ?>); max-height: 535px !important;" class="item has-pattern">
                <div class="container">
                    <div class="row" style="color: #fff">
                        <div class="col-lg-6">
                            <h1 style="color: #d59431;font-size: 2.0rem"></h1>
                            <ul class="lead">
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                            </ul>
                            <p>&nbsp;</p>
                            
                        </div>
                    </div>
                </div>
            </div>

            <!-- Banner 2 -->
            <div style="background: url(<?php echo e(asset('img/app/bg-img/hero-bg-2.png')); ?>); max-height: 535px !important;" class="item has-pattern">
                <div class="container">
                    <div class="row" style="color: #fff">
                        <div class="col-lg-6">
                            <h1 style="color: #d59431; font-size: 2.0rem"></h1>
                            <ul class="lead">
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                            </ul>
                            <p>&nbsp;</p>
                            
                        </div>
                    </div>
                </div>
            </div>

            <!-- Banner 3 -->
            <div style="background: url(<?php echo e(asset('img/app/bg-img/hero-bg-3.png')); ?>); max-height: 535px !important;" class="item has-pattern">
                <div class="container">
                    <div class="row" style="color: #fff">
                        <div class="col-lg-6">
                            <h1 style="color: #d59431; font-size: 2.0rem"></h1>
                            <ul class="lead">
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                                <p>&nbsp;</p>
                            </ul>
                            <p>&nbsp;</p>
                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <section class="new_arrivals_area section_padding_100_0 clearfix">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="section_heading text-center">
                        <img src="<?php echo e(asset('img/app/bg-img/novosprodutos.png')); ?>">
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row karl-new-arrivals text-center">
                <?php $__currentLoopData = $produtos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $produto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-12 col-sm-4 col-md-3 single_gallery_item shoes wow fadeInUpBig">
                        <div class="product-img">
                            <img class="tamanhoimg" src="<?php echo e(URL::asset('img/products/' . $produto->im_produto)); ?>" alt="<?php echo e($produto->nm_slug); ?>">
                            <div class="product-quicview">
                                <a href="<?php echo e(route('products.details', $produto->nm_slug)); ?>"><i class="fa fa-plus"></i></a>
                            </div>
                        </div>

                        <div class="product-description">
                            <h4 style="color: #d59431" class="product-price">R$ <?php echo e(str_replace(".", ",", $produto->vl_produto)); ?></h4>
                            <p style="max-height: 20px; text-overflow: ellipsis"><?php echo e($produto->nm_produto); ?></p>
                            <p>&nbsp;</p>
                            <p>&nbsp;</p>


                            <form action="<?php echo e(route('cart.buy')); ?>" method="post">
                                <?php echo e(csrf_field()); ?>


                                <input type="hidden" name="cd_produto" value="<?php echo e($produto->cd_produto); ?>">
                                <input type="hidden" name="nm_produto" value="<?php echo e($produto->nm_produto); ?>">
                                <input type="hidden" name="ds_produto" value="<?php echo e($produto->ds_produto); ?>">
                                <input type="hidden" name="vl_produto" value="<?php echo e($produto->vl_produto); ?>">
                                <input type="hidden" name="qt_produto" value="<?php echo e($produto->qt_produto); ?>">
                                <input type="hidden" name="sku_produto" value="<?php echo e($produto->cd_nr_sku); ?>">
                                <input type="hidden" name="slug_produto" value="<?php echo e($produto->nm_slug); ?>">
                                <input type="hidden" name="ds_altura" value="<?php echo e($produto->ds_altura); ?>">
                                <input type="hidden" name="ds_largura" value="<?php echo e($produto->ds_largura); ?>">
                                <input type="hidden" name="ds_comprimento" value="<?php echo e($produto->ds_comprimento); ?>">
                                <input type="hidden" name="ds_peso" value="<?php echo e($produto->ds_peso); ?>">
                                <input type="hidden" name="im_produto" value="<?php echo e($produto->im_produto); ?>">
                                <?php if($produto->qt_produto < 5): ?>
                                    <div>
                                        <p class="btn semestoque">SEM ESTOQUE</p>
                                    </div>
                                <?php else: ?>
                                    <div>
                                        <button type="submit" class="btn btncomprar" style="overflow: hidden"><i class="fa fa-shopping-cart" aria-hidden="true"></i>&nbsp;COMPRAR</button>
                                    </div>
                                <?php endif; ?>
                            </form>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
       
    </section>



    <section class="offer_area height-700 section_padding_100 bg-img" style="background-image: url(<?php echo e(asset('img/app/bg-img/bg-5.png')); ?>);">
        <div class="container h-100">
            <div class="row h-100 align-items-end justify-content-end">
                <div class="col-12 col-md-8 col-lg-6">
                    <div class="offer-content-area wow fadeInUp" data-wow-delay="1s">
                        <h2>Oferta Especial <span class="karl-level">Hot</span></h2>
                        <p>Catharine Hill Sombras Variadas 1017 - Paleta De Sombras Com 30 Cores Diferentes De Acabamentos Opacos E Cintilantes.</p>
                        <div class="offer-product-price">
                            <h3><span class="regular-price">R$126,99</span> R$106,99</h3>
                        </div>
                        <a href="<?php echo e(route('products.details', 'catharine-hill-paleta-de-sombras-variadas-30-cores')); ?>" target="_blank" class="btn btn-template wide shop-now">Comprar Agora</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <script src="<?php echo e(asset('js/app/magnific.min.js')); ?>"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>